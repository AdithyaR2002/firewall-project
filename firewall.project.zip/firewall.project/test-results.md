# 🔍 Firewall Testing Results Using nmap

## Command Used:

```bash
nmap localhost
